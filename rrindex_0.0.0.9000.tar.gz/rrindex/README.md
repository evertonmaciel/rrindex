# rareindex
A r package to calculate a rarity index

# Overview

# Developer

# Install rareindex from github

install.packages('devtools')

library(devtools)

install_github('evertonmaciel/rareindex')

# Import packages
library(rareindex)

# Usage

rrindex()

#Function to calculate the rarity index for each species of community based on the Rabinowitz method 




